package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface StudentScheduleDao {
    @Query("SELECT * FROM student_schedules")
    fun getAllStudentSchedules(): Flow<List<StudentScheduleEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudentSchedule(schedule: StudentScheduleEntity)

    @Update
    suspend fun updateStudentSchedule(schedule: StudentScheduleEntity)

    @Delete
    suspend fun deleteStudentSchedule(schedule: StudentScheduleEntity)

    @Query("DELETE FROM student_schedules WHERE id = :id")
    suspend fun deleteStudentScheduleById(id: Int)
}
