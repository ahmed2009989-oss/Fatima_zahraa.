package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface SheikhDao {
    @Query("SELECT * FROM sheikhs")
    fun getAllSheikhs(): Flow<List<SheikhEntity>>

    @Query("SELECT * FROM sheikhs WHERE id = :id")
    suspend fun getSheikhById(id: Int): SheikhEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSheikhs(sheikhs: List<SheikhEntity>)

    @Update
    suspend fun updateSheikh(sheikh: SheikhEntity)
}
