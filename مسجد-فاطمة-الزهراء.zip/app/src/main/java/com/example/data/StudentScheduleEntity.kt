package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "student_schedules")
data class StudentScheduleEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val studentName: String,
    val sheikhId: Int,
    val day: String,
    val time: String,
    val task: String,
    val notes: String = ""
)
