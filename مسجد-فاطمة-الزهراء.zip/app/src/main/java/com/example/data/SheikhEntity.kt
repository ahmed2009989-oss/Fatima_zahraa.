package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sheikhs")
data class SheikhEntity(
    @PrimaryKey val id: Int,
    val name: String,
    val days: String,
    val shiftHours: String,
    val monthlyDeductions: Int,
    val totalLostHours: Double,
    val delayCount: Int
)
