package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MosqueViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    private val repository = MosqueRepository(database.sheikhDao(), database.studentScheduleDao())

    private val _sheikhs = MutableStateFlow<List<SheikhEntity>>(emptyList())
    val sheikhs: StateFlow<List<SheikhEntity>> = _sheikhs.asStateFlow()

    private val _studentSchedules = MutableStateFlow<List<StudentScheduleEntity>>(emptyList())
    val studentSchedules: StateFlow<List<StudentScheduleEntity>> = _studentSchedules.asStateFlow()

    init {
        viewModelScope.launch {
            // First prepopulate if database is empty
            repository.prepopulateIfEmpty()

            // Collect Sheikhs Flow
            launch {
                repository.allSheikhs.collectLatest { list ->
                    _sheikhs.value = list
                }
            }

            // Collect StudentSchedules Flow
            launch {
                repository.allStudentSchedules.collectLatest { list ->
                    _studentSchedules.value = list
                }
            }
        }
    }

    fun addStudentSchedule(
        studentName: String,
        sheikhId: Int,
        day: String,
        time: String,
        task: String,
        notes: String
    ) {
        viewModelScope.launch {
            val schedule = StudentScheduleEntity(
                studentName = studentName,
                sheikhId = sheikhId,
                day = day,
                time = time,
                task = task,
                notes = notes
            )
            repository.insertStudentSchedule(schedule)
        }
    }

    fun updateStudentSchedule(
        id: Int,
        studentName: String,
        sheikhId: Int,
        day: String,
        time: String,
        task: String,
        notes: String
    ) {
        viewModelScope.launch {
            val schedule = StudentScheduleEntity(
                id = id,
                studentName = studentName,
                sheikhId = sheikhId,
                day = day,
                time = time,
                task = task,
                notes = notes
            )
            repository.updateStudentSchedule(schedule)
        }
    }

    fun deleteStudentSchedule(scheduleId: Int) {
        viewModelScope.launch {
            repository.deleteStudentScheduleById(scheduleId)
        }
    }

    fun performSheikhCheckIn(sheikhId: Int, arrivalMinutesOffset: Int) {
        viewModelScope.launch {
            val sheikh = repository.getSheikhById(sheikhId) ?: return@launch
            
            // Check-in logic:
            // Standard shift start is 01:30 PM (90 minutes from 12:00 PM)
            // arrivalMinutesOffset is minutes of delay from 01:30 PM.
            // If delay is > 15 minutes, apply 50 EGP deduction, increment delayCount, and add delay to totalLostHours.
            
            val isLate = arrivalMinutesOffset > 15
            val updatedDeductions = if (isLate) sheikh.monthlyDeductions - 50 else sheikh.monthlyDeductions
            val updatedDelayCount = if (isLate) sheikh.delayCount + 1 else sheikh.delayCount
            
            // Convert arrival minutes of delay into hours to add to total lost hours
            val lostHoursAddition = if (isLate) (arrivalMinutesOffset.toDouble() / 60.0) else 0.0
            val updatedLostHours = sheikh.totalLostHours + lostHoursAddition

            val updatedSheikh = sheikh.copy(
                monthlyDeductions = updatedDeductions,
                delayCount = updatedDelayCount,
                totalLostHours = Math.round(updatedLostHours * 10.0) / 10.0 // round to 1 decimal place
            )
            
            repository.updateSheikh(updatedSheikh)
        }
    }

    fun resetSheikhStats(sheikhId: Int) {
        viewModelScope.launch {
            val sheikh = repository.getSheikhById(sheikhId) ?: return@launch
            val updatedSheikh = sheikh.copy(
                monthlyDeductions = 0,
                delayCount = 0,
                totalLostHours = 0.0
            )
            repository.updateSheikh(updatedSheikh)
        }
    }
}
