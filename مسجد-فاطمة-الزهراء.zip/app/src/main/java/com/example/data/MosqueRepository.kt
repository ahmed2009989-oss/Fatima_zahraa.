package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class MosqueRepository(
    private val sheikhDao: SheikhDao,
    private val studentScheduleDao: StudentScheduleDao
) {
    val allSheikhs: Flow<List<SheikhEntity>> = sheikhDao.getAllSheikhs()
    val allStudentSchedules: Flow<List<StudentScheduleEntity>> = studentScheduleDao.getAllStudentSchedules()

    suspend fun getSheikhById(id: Int): SheikhEntity? = sheikhDao.getSheikhById(id)

    suspend fun updateSheikh(sheikh: SheikhEntity) {
        sheikhDao.updateSheikh(sheikh)
    }

    suspend fun insertStudentSchedule(schedule: StudentScheduleEntity) {
        studentScheduleDao.insertStudentSchedule(schedule)
    }

    suspend fun updateStudentSchedule(schedule: StudentScheduleEntity) {
        studentScheduleDao.updateStudentSchedule(schedule)
    }

    suspend fun deleteStudentSchedule(schedule: StudentScheduleEntity) {
        studentScheduleDao.deleteStudentSchedule(schedule)
    }

    suspend fun deleteStudentScheduleById(id: Int) {
        studentScheduleDao.deleteStudentScheduleById(id)
    }

    suspend fun prepopulateIfEmpty() {
        val currentSheikhs = sheikhDao.getAllSheikhs().first()
        if (currentSheikhs.isEmpty()) {
            val defaultSheikhs = listOf(
                SheikhEntity(
                    id = 1,
                    name = "الشيخ علي سعيد",
                    days = "السبت والثلاثاء",
                    shiftHours = "01:30 م - 06:00 م",
                    monthlyDeductions = -150,
                    totalLostHours = 3.0,
                    delayCount = 3
                ),
                SheikhEntity(
                    id = 2,
                    name = "الشيخ محمد أسامة",
                    days = "الاثنين والخميس",
                    shiftHours = "01:30 م - 06:00 م",
                    monthlyDeductions = 0,
                    totalLostHours = 0.0,
                    delayCount = 0
                )
            )
            sheikhDao.insertSheikhs(defaultSheikhs)
        }

        val currentSchedules = studentScheduleDao.getAllStudentSchedules().first()
        if (currentSchedules.isEmpty()) {
            val defaultSchedules = listOf(
                StudentScheduleEntity(
                    studentName = "أحمد محمد",
                    sheikhId = 1,
                    day = "السبت",
                    time = "01:30 م",
                    task = "مراجعة سورة البقرة",
                    notes = "قراءة جيدة بالتجويد"
                ),
                StudentScheduleEntity(
                    studentName = "عمر فاروق",
                    sheikhId = 1,
                    day = "الثلاثاء",
                    time = "03:00 م",
                    task = "حفظ جزء عم",
                    notes = "تسميع سورة النبأ"
                ),
                StudentScheduleEntity(
                    studentName = "محمد أحمد",
                    sheikhId = 2,
                    day = "الاثنين",
                    time = "02:00 م",
                    task = "تسميع سورة البقرة من آية ١ إلى ٥٠",
                    notes = "تحسين مخارج الحروف"
                ),
                StudentScheduleEntity(
                    studentName = "يوسف عمر",
                    sheikhId = 2,
                    day = "الخميس",
                    time = "04:30 م",
                    task = "مراجعة جزء تبارك",
                    notes = "مستوى ممتاز"
                )
            )
            for (schedule in defaultSchedules) {
                studentScheduleDao.insertStudentSchedule(schedule)
            }
        }
    }
}
