package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryEmerald = Color(0xFF003527)
val PrimaryContainerEmerald = Color(0xFF064E3B)
val OnPrimaryContainerEmerald = Color(0xFF80BEA6)

val SecondaryGold = Color(0xFF735C00)
val SecondaryContainerGold = Color(0xFFFED65B)
val OnSecondaryContainerGold = Color(0xFF745C00)

val SurfaceIvory = Color(0xFFF8F9FF)
val OnSurfaceSlate = Color(0xFF121C28)
val OnSurfaceVariantSlate = Color(0xFF404944)

val SurfaceContainerLowest = Color(0xFFFFFFFF)
val SurfaceContainerLow = Color(0xFFEEF4FF)
val SurfaceContainerNormal = Color(0xFFE5EEFF)
val SurfaceContainerHigh = Color(0xFFDFE9FA)
val SurfaceContainerHighest = Color(0xFFD9E3F4)

val ErrorRed = Color(0xFFBA1A1A)
val OnErrorWhite = Color(0xFFFFFFFF)

val GoldAccent = Color(0xFFD4AF37)
