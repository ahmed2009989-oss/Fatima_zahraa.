package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.data.SheikhEntity
import com.example.data.StudentScheduleEntity
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.MosqueViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                // Force RTL Layout Direction for beautiful Arabic Quranic/Mosque Theme
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    val navController = rememberNavController()
                    val mosqueViewModel: MosqueViewModel = viewModel()
                    
                    var currentRoute by remember { mutableStateOf("attendance") }

                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        topBar = {
                            MosqueTopAppBar()
                        },
                        bottomBar = {
                            MosqueBottomNavigation(
                                currentRoute = currentRoute,
                                onNavigate = { route ->
                                    if (route == "attendance" || route == "student_schedule") {
                                        currentRoute = route
                                        navController.navigate(route) {
                                            popUpTo("attendance") { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    } else {
                                        // Display a helpful premium feedback for non-implemented placeholder items
                                        Toast.makeText(
                                            this,
                                            "هذه الميزة (المصاريف/الاختبارات) ستكون متاحة قريباً في التحديث القادم!",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                }
                            )
                        }
                    ) { innerPadding ->
                        NavHost(
                            navController = navController,
                            startDestination = "attendance",
                            modifier = Modifier.padding(innerPadding)
                        ) {
                            composable("attendance") {
                                currentRoute = "attendance"
                                AttendanceScreen(
                                    viewModel = mosqueViewModel,
                                    onSheikhCardClicked = { sheikhId ->
                                        currentRoute = "student_schedule"
                                        navController.navigate("student_schedule") {
                                            launchSingleTop = true
                                        }
                                    }
                                )
                            }
                            composable("student_schedule") {
                                currentRoute = "student_schedule"
                                StudentScheduleScreen(
                                    viewModel = mosqueViewModel
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MosqueTopAppBar() {
    val context = LocalContext.current
    TopAppBar(
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Mosque,
                    contentDescription = "Mosque Logo",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(28.dp)
                )
                Text(
                    text = "مسجد فاطمة الزهراء",
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        },
        actions = {
            IconButton(
                onClick = {
                    Toast.makeText(context, "لا توجد إشعارات جديدة حالياً", Toast.LENGTH_SHORT).show()
                }
            ) {
                BadgedBox(
                    badge = { Badge { Text("0") } }
                ) {
                    Icon(
                        imageVector = Icons.Default.Notifications,
                        contentDescription = "Notifications",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    )
}

@Composable
fun MosqueBottomNavigation(
    currentRoute: String,
    onNavigate: (String) -> Unit
) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surfaceVariant,
        tonalElevation = 8.dp,
        modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        NavigationBarItem(
            selected = currentRoute == "home_placeholder", // Just a helper, clicking home takes to attendance
            onClick = { onNavigate("attendance") },
            icon = { Icon(Icons.Outlined.Home, contentDescription = "الرئيسية") },
            label = { Text("الرئيسية", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = MaterialTheme.colorScheme.primary,
                indicatorColor = MaterialTheme.colorScheme.primaryContainer
            ),
            modifier = Modifier.testTag("nav_home")
        )
        NavigationBarItem(
            selected = currentRoute == "attendance",
            onClick = { onNavigate("attendance") },
            icon = { Icon(Icons.Default.Mosque, contentDescription = "المشايخ") },
            label = { Text("المشايخ", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = MaterialTheme.colorScheme.primary,
                indicatorColor = MaterialTheme.colorScheme.primaryContainer
            ),
            modifier = Modifier.testTag("nav_sheikhs")
        )
        NavigationBarItem(
            selected = currentRoute == "student_schedule",
            onClick = { onNavigate("student_schedule") },
            icon = { Icon(Icons.Outlined.Group, contentDescription = "الطلاب") },
            label = { Text("الطلاب", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = MaterialTheme.colorScheme.primary,
                indicatorColor = MaterialTheme.colorScheme.primaryContainer
            ),
            modifier = Modifier.testTag("nav_students")
        )
        NavigationBarItem(
            selected = false,
            onClick = { onNavigate("expenses") },
            icon = { Icon(Icons.Outlined.Payments, contentDescription = "المصاريف") },
            label = { Text("المصاريف", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
            modifier = Modifier.testTag("nav_expenses")
        )
        NavigationBarItem(
            selected = false,
            onClick = { onNavigate("tests") },
            icon = { Icon(Icons.Outlined.Assignment, contentDescription = "الاختبارات") },
            label = { Text("الاختبارات", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
            modifier = Modifier.testTag("nav_tests")
        )
    }
}

@Composable
fun AttendanceScreen(
    viewModel: MosqueViewModel,
    onSheikhCardClicked: (Int) -> Unit
) {
    val sheikhs by viewModel.sheikhs.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var selectedSheikhForCheckIn by remember { mutableStateOf<SheikhEntity?>(null) }
    var delayMinutesText by remember { mutableStateOf("0") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // Hero Section
        item {
            Column(modifier = Modifier.padding(vertical = 12.dp)) {
                Text(
                    text = "حضور المشايخ",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "إدارة تسجيل الدخول اليومي وتتبع الأداء الشهري مع احتساب الخصومات التلقائية لهيئة التدريس.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // Attendance Policy Banner
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Policy Info",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Column {
                        Text(
                            text = "سياسة الحضور",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 16.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "أي تأخير يتجاوز 15 دقيقة عن موعد البدء المحدد سيؤدي إلى خصم 50 جنيه مصري (ما يعادل ساعة تدريس واحدة).",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        }

        // Bento Grid of Sheikhs (List of Cards)
        items(sheikhs) { sheikh ->
            SheikhBentoCard(
                sheikh = sheikh,
                onCheckInClick = {
                    selectedSheikhForCheckIn = sheikh
                    delayMinutesText = "0"
                },
                onCheckOutClick = {
                    Toast.makeText(context, "تم تسجيل خروج الشيخ ${sheikh.name} بنجاح!", Toast.LENGTH_SHORT).show()
                },
                onCardClick = {
                    onSheikhCardClicked(sheikh.id)
                }
            )
        }

        // Deductions Summary Section
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f))
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "ملخص الخصومات",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "نظرة عامة على الشهر الحالي",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Button(
                        onClick = {
                            Toast.makeText(
                                context,
                                "تم تصدير تقرير الخصومات بنجاح بصيغة PDF!",
                                Toast.LENGTH_LONG
                            ).show()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.secondary,
                            contentColor = MaterialTheme.colorScheme.onSecondary
                        ),
                        shape = RoundedCornerShape(20.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = "Export Report",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تصدير التقرير", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Table Layout
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        // Table Headers
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                "اسم الشيخ",
                                modifier = Modifier.weight(1.5f),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                "الساعات المفقودة",
                                modifier = Modifier.weight(1.5f),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                "التأخير (>15 د)",
                                modifier = Modifier.weight(1.2f),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                "الخصم",
                                modifier = Modifier.weight(1f),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                textAlign = TextAlign.End
                            )
                        }

                        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))

                        // Table Rows
                        sheikhs.forEach { sheikh ->
                            val hourText = if (sheikh.totalLostHours > 0) "${sheikh.totalLostHours} ساعة" else "0 ساعة"
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    sheikh.name,
                                    modifier = Modifier.weight(1.5f),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    hourText,
                                    modifier = Modifier.weight(1.5f),
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center
                                )
                                Text(
                                    "${sheikh.delayCount} مرات",
                                    modifier = Modifier.weight(1.2f),
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center
                                )
                                Text(
                                    "${sheikh.monthlyDeductions} ج.م",
                                    modifier = Modifier.weight(1f),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (sheikh.monthlyDeductions < 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                                    textAlign = TextAlign.End
                                )
                            }
                            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.08f))
                        }
                    }
                }
            }
        }
    }

    // Interactive Check-In Dialogue
    selectedSheikhForCheckIn?.let { sheikh ->
        Dialog(onDismissRequest = { selectedSheikhForCheckIn = null }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Alarm,
                        contentDescription = "Time Check",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "تسجيل حضور الشيخ",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = sheikh.name,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "بداية الوردية المعتادة: 01:30 م.\nكم دقيقة تأخر الشيخ عن موعد البدء؟",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    OutlinedTextField(
                        value = delayMinutesText,
                        onValueChange = { delayMinutesText = it.filter { char -> char.isDigit() } },
                        label = { Text("دقائق التأخير") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline
                        )
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = { selectedSheikhForCheckIn = null },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("إلغاء", color = MaterialTheme.colorScheme.primary)
                        }
                        Button(
                            onClick = {
                                val delayMinutes = delayMinutesText.toIntOrNull() ?: 0
                                viewModel.performSheikhCheckIn(sheikh.id, delayMinutes)
                                val isLate = delayMinutes > 15
                                val msg = if (isLate) {
                                    "تأخير ${delayMinutes} دقيقة. تم تسجيل حضور متأخر وتطبيق خصم 50 ج.م تلقائياً."
                                } else {
                                    "تم تسجيل حضور الشيخ في الموعد المحدد بنجاح!"
                                }
                                Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                selectedSheikhForCheckIn = null
                            },
                            modifier = Modifier.weight(1.5f),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("تسجيل الحضور", color = MaterialTheme.colorScheme.onPrimary)
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    TextButton(
                        onClick = {
                            viewModel.resetSheikhStats(sheikh.id)
                            Toast.makeText(context, "تمت إعادة تعيين خصومات وإحصائيات الشيخ بنجاح.", Toast.LENGTH_SHORT).show()
                            selectedSheikhForCheckIn = null
                        }
                    ) {
                        Text("إعادة تعيين إحصائيات الشهر", color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun SheikhBentoCard(
    sheikh: SheikhEntity,
    onCheckInClick: () -> Unit,
    onCheckOutClick: () -> Unit,
    onCardClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCardClick() }
            .testTag("sheikh_card_${sheikh.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Sheikh Header info
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(
                                if (sheikh.id == 1) MaterialTheme.colorScheme.primaryContainer
                                else MaterialTheme.colorScheme.secondaryContainer
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = sheikh.name,
                            tint = if (sheikh.id == 1) MaterialTheme.colorScheme.onPrimaryContainer
                            else MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    Column {
                        Text(
                            text = sheikh.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CalendarToday,
                                contentDescription = "Days",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                text = sheikh.days,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                
                // Mosque decorative background shape
                Icon(
                    imageVector = if (sheikh.id == 1) Icons.Default.Mosque else Icons.Default.MenuBook,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                    modifier = Modifier.size(48.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Details section
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        MaterialTheme.colorScheme.background.copy(alpha = 0.6f),
                        RoundedCornerShape(8.dp)
                    )
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "ساعات الوردية",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = sheikh.shiftHours,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "خصومات الشهر",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "${sheikh.monthlyDeductions} ج.م",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (sheikh.monthlyDeductions < 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { onCheckInClick() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(vertical = 12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Login,
                        contentDescription = "Check-In",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("تسجيل دخول", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = { onCheckOutClick() },
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.primary
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(vertical = 12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Logout,
                        contentDescription = "Check-Out",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("تسجيل خروج", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentScheduleScreen(
    viewModel: MosqueViewModel
) {
    val schedules by viewModel.studentSchedules.collectAsStateWithLifecycle()
    val sheikhs by viewModel.sheikhs.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var selectedSheikhIdFilter by remember { mutableStateOf<Int?>(null) }
    var selectedDayFilter by remember { mutableStateOf<String?>(null) }

    var showFormDialog by remember { mutableStateOf(false) }
    var editingSchedule by remember { mutableStateOf<StudentScheduleEntity?>(null) }

    // Form Fields State
    var studentName by remember { mutableStateOf("") }
    var sheikhIdSelection by remember { mutableStateOf(1) }
    var selectedDaySelection by remember { mutableStateOf("السبت") }
    var appointmentTime by remember { mutableStateOf("01:30 م") }
    var memorizationTask by remember { mutableStateOf("") }
    var appointmentNotes by remember { mutableStateOf("") }

    // Dropdown / Row filters options
    val daysList = listOf("السبت", "الاثنين", "الثلاثاء", "الخميس")

    // Filter schedules
    val filteredSchedules = schedules.filter { schedule ->
        val matchSheikh = selectedSheikhIdFilter == null || schedule.sheikhId == selectedSheikhIdFilter
        val matchDay = selectedDayFilter == null || schedule.day == selectedDayFilter
        matchSheikh && matchDay
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            // Screen Title & Description
            Column(modifier = Modifier.padding(vertical = 12.dp)) {
                Text(
                    text = "مواعيد الطلاب",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "إدارة وتعديل جدول مواعيد الحلقات للطلاب المقيدين بالمسجد.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Filters Section
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "تصنيف وجدولة المواعيد حسب:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    
                    // Sheikh Filter Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("الشيخ:", fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(42.dp))
                        
                        FilterChip(
                            selected = selectedSheikhIdFilter == null,
                            onClick = { selectedSheikhIdFilter = null },
                            label = { Text("الكل", fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.primary
                            )
                        )
                        sheikhs.forEach { sheikh ->
                            FilterChip(
                                selected = selectedSheikhIdFilter == sheikh.id,
                                onClick = { selectedSheikhIdFilter = sheikh.id },
                                label = { Text(sheikh.name.replace("الشيخ ", ""), fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                    selectedLabelColor = MaterialTheme.colorScheme.primary
                                )
                            )
                        }
                    }

                    // Day Filter Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("اليوم:", fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(42.dp))
                        
                        FilterChip(
                            selected = selectedDayFilter == null,
                            onClick = { selectedDayFilter = null },
                            label = { Text("الكل", fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.primary
                            )
                        )
                        daysList.forEach { day ->
                            FilterChip(
                                selected = selectedDayFilter == day,
                                onClick = { selectedDayFilter = day },
                                label = { Text(day, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                    selectedLabelColor = MaterialTheme.colorScheme.primary
                                )
                            )
                        }
                    }
                }
            }

            // Schedules list
            if (filteredSchedules.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.EventBusy,
                            contentDescription = "No appointments",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "لا توجد مواعيد مضافة تطابق التصفية الحالية.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 14.sp
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(filteredSchedules) { schedule ->
                        val sheikhName = sheikhs.find { it.id == schedule.sheikhId }?.name ?: "الشيخ"
                        StudentScheduleCard(
                            schedule = schedule,
                            sheikhName = sheikhName,
                            onEditClick = {
                                editingSchedule = schedule
                                studentName = schedule.studentName
                                sheikhIdSelection = schedule.sheikhId
                                selectedDaySelection = schedule.day
                                appointmentTime = schedule.time
                                memorizationTask = schedule.task
                                appointmentNotes = schedule.notes
                                showFormDialog = true
                            },
                            onDeleteClick = {
                                viewModel.deleteStudentSchedule(schedule.id)
                                Toast.makeText(context, "تم حذف الموعد بنجاح.", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                }
            }
        }

        // FAB to add new schedule
        FloatingActionButton(
            onClick = {
                editingSchedule = null
                studentName = ""
                sheikhIdSelection = 1
                selectedDaySelection = "السبت"
                appointmentTime = "01:30 م"
                memorizationTask = ""
                appointmentNotes = ""
                showFormDialog = true
            },
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 16.dp, end = 16.dp)
                .testTag("add_schedule_fab")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة موعد")
                Spacer(modifier = Modifier.width(6.dp))
                Text("إضافة موعد", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }

        // Add / Edit Dialog Form
        if (showFormDialog) {
            Dialog(onDismissRequest = { showFormDialog = false }) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                ) {
                    LazyColumn(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        item {
                            Text(
                                text = if (editingSchedule == null) "إضافة حلقة جديدة للطلاب" else "تعديل حلقة الطالب",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.fillMaxWidth(),
                                textAlign = TextAlign.Center
                            )
                        }

                        // Student Name
                        item {
                            OutlinedTextField(
                                value = studentName,
                                onValueChange = { studentName = it },
                                label = { Text("اسم الطالب ثلاثي") },
                                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                        }

                        // Select Sheikh Selection
                        item {
                            Text("اختر الشيخ المحفظ:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                sheikhs.forEach { sheikh ->
                                    val isSelected = sheikhIdSelection == sheikh.id
                                    Card(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable { sheikhIdSelection = sheikh.id },
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                        ),
                                        border = BorderStroke(
                                            1.dp,
                                            if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent
                                        )
                                    ) {
                                        Text(
                                            text = sheikh.name,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                            modifier = Modifier
                                                .padding(8.dp)
                                                .fillMaxWidth(),
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }
                            }
                        }

                        // Day Select row
                        item {
                            Text("اختر يوم التسميع:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                daysList.forEach { day ->
                                    val isSelected = selectedDaySelection == day
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (isSelected) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                                            .clickable { selectedDaySelection = day }
                                            .padding(vertical = 8.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = day,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSelected) MaterialTheme.colorScheme.onSecondaryContainer else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }

                        // Time Input & Task Input
                        item {
                            OutlinedTextField(
                                value = appointmentTime,
                                onValueChange = { appointmentTime = it },
                                label = { Text("الموعد (مثال: 02:30 م)") },
                                leadingIcon = { Icon(Icons.Default.AccessTime, contentDescription = null) },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                        }

                        item {
                            OutlinedTextField(
                                value = memorizationTask,
                                onValueChange = { memorizationTask = it },
                                label = { Text("جزء الحفظ / الورد الحالي") },
                                leadingIcon = { Icon(Icons.Default.MenuBook, contentDescription = null) },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                        }

                        // Notes Input
                        item {
                            OutlinedTextField(
                                value = appointmentNotes,
                                onValueChange = { appointmentNotes = it },
                                label = { Text("ملاحظات إضافية") },
                                leadingIcon = { Icon(Icons.Default.EditNote, contentDescription = null) },
                                modifier = Modifier.fillMaxWidth(),
                                maxLines = 3
                            )
                        }

                        // Submit & Cancel Action buttons
                        item {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 12.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { showFormDialog = false },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("إلغاء", color = MaterialTheme.colorScheme.primary)
                                }
                                Button(
                                    onClick = {
                                        if (studentName.trim().isEmpty() || memorizationTask.trim().isEmpty()) {
                                            Toast.makeText(context, "الرجاء تعبئة اسم الطالب ومقدار الحفظ أولاً!", Toast.LENGTH_SHORT).show()
                                        } else {
                                            val schedule = editingSchedule
                                            if (schedule == null) {
                                                viewModel.addStudentSchedule(
                                                    studentName = studentName,
                                                    sheikhId = sheikhIdSelection,
                                                    day = selectedDaySelection,
                                                    time = appointmentTime,
                                                    task = memorizationTask,
                                                    notes = appointmentNotes
                                                )
                                                Toast.makeText(context, "تم إضافة موعد الطالب بنجاح!", Toast.LENGTH_SHORT).show()
                                            } else {
                                                viewModel.updateStudentSchedule(
                                                    id = schedule.id,
                                                    studentName = studentName,
                                                    sheikhId = sheikhIdSelection,
                                                    day = selectedDaySelection,
                                                    time = appointmentTime,
                                                    task = memorizationTask,
                                                    notes = appointmentNotes
                                                )
                                                Toast.makeText(context, "تم تحديث موعد الطالب بنجاح!", Toast.LENGTH_SHORT).show()
                                            }
                                            showFormDialog = false
                                        }
                                    },
                                    modifier = Modifier.weight(1.5f),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                ) {
                                    Text(
                                        text = if (editingSchedule == null) "حفظ وإضافة" else "تحديث الموعد",
                                        color = MaterialTheme.colorScheme.onPrimary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StudentScheduleCard(
    schedule: StudentScheduleEntity,
    sheikhName: String,
    onEditClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Student Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.School,
                            contentDescription = "Student Icon",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Column {
                        Text(
                            text = schedule.studentName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "المحفظ: $sheikhName",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.secondary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Delete Button
                IconButton(
                    onClick = { onDeleteClick() }
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "حذف الحلقة",
                        tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Divider(
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.08f),
                modifier = Modifier.padding(vertical = 10.dp)
            )

            // Schedule Day / Time Info & Task Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Day & Time Badge
                Card(
                    shape = RoundedCornerShape(6.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.08f)),
                    modifier = Modifier.weight(1.1f)
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = schedule.day,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = schedule.time,
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Task Badge
                Card(
                    shape = RoundedCornerShape(6.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.15f)),
                    modifier = Modifier.weight(2f)
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(
                            text = "موضوع الحلقة:",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = schedule.task,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // Notes if available
            if (schedule.notes.trim().isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                            RoundedCornerShape(6.dp)
                        )
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Default.EditNote,
                        contentDescription = "Notes Icon",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = schedule.notes,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 14.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Edit Action bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(
                    onClick = { onEditClick() },
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.height(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Edit",
                        modifier = Modifier.size(14.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("تعديل تفاصيل الحلقة", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}
